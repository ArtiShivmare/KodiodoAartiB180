package problem1;
import java.util.*;  

public class List {
	
	
	public static void main(String args[]){ 
	    
	 
	ArrayList<Integer> list = new ArrayList<Integer>();
	    
	  
	list.add(10);   
	list.add(5);   
	list.add(20);   
	list.add(25);   
	list.add(35);   
	list.add(30);   
	list.add(80);  
	list.add(50);  
	    
	 
	System.out.println("Before Sorting: "+ list); 
	    
	 
	Collections.sort(list);   
	    
	  
	System.out.println("After Sorting: "+ list);  
	    
	    }   
	}  


