package problem1;

import java.util.Arrays;

public class Student {
    int rollno;
    String name;
    int marks;
    
    public static void main(String args[]) {
    	int arr[]= {10, 20, 30, 40};
		Arrays.sort(arr);
		System.out.println("ArrayList in desending order");
		for (int i:arr)
		{
			System.out.println(i);
		}
		System.out.println("============================");
		System.out.println("min list:"+arr[0]);
		System.out.println("max list:"+ arr[arr.length-1]);

	}
    }
    

