package problem2;

public class TestCase2 {

	public static void main(String[] args) {
		int a=6;
		int b=9;
		if(a % 2 == 0) {
			
			System.out.println("Sum of even digits");
			
		     System.out.println("Number in odd"+a);
		}else {
			System.out.println("Number is even"+b);
		}
		
	}

}
